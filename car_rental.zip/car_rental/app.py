# -*- coding: utf-8 -*-
from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///car_rental.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Модель для автомобілів
class Car(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    model = db.Column(db.String(50), nullable=False)
    location = db.Column(db.String(50), nullable=False)
    image = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float, nullable=False)
    description = db.Column(db.String(200), nullable=False)

# Модель для записів оренди
class RentalRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20), nullable=False)
    pickup_location = db.Column(db.String(50), nullable=False)
    pickup_date = db.Column(db.String(20), nullable=False)
    return_date = db.Column(db.String(20), nullable=False)
    car_model = db.Column(db.String(50), nullable=False)

with app.app_context():
    db.create_all()

    if Car.query.count() == 0:
        initial_cars = [
            Car(model='Ford Mustang', location='Локація 1', image='images/car1.jpg', price=100, description='Відчуйте потужність і стиль легендарного Ford Mustang, який поєднує в собі швидкість та комфорт для незабутніх подорожей.'),
            Car(model='Chevrolet Camaro', location='Локація 2', image='images/car2.jpg', price=90, description='Сядьте за кермо Chevrolet Camaro та насолоджуйтесь динамікою і маневреністю цього автомобіля, який створений для справжніх поціновувачів драйву.'),
            Car(model='BMW M3', location='Локація 3', image='images/car3.jpg', price=120, description='Насолоджуйтесь розкішшю і продуктивністю BMW M3 - автомобіля, що поєднує в собі передові технології і бездоганний дизайн.')
        ]
        db.session.bulk_save_objects(initial_cars)
        db.session.commit()

@app.route('/')
def index():
    cars = Car.query.all()
    return render_template('index.html', cars=cars)

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/cars')
def cars():
    cars = Car.query.all()
    return render_template('cars.html', cars=cars)

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/checkout', methods=['GET', 'POST'])
def checkout():
    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        phone = request.form['phone']
        pickup_location = request.form['pickup_location']
        pickup_date = request.form['pickup_date']
        return_date = request.form['return_date']
        car_model = request.form['car_model']

        rental_record = RentalRecord(
            full_name=full_name,
            email=email,
            phone=phone,
            pickup_location=pickup_location,
            pickup_date=pickup_date,
            return_date=return_date,
            car_model=car_model
        )

        db.session.add(rental_record)
        db.session.commit()

        return redirect(url_for('index'))
    
    cars = Car.query.all()
    return render_template('checkout.html', cars=cars)

@app.route('/rentals')
def rentals():
    records = RentalRecord.query.all()
    return render_template('rentals.html', records=records)

if __name__ == '__main__':
    app.run(debug=True)
